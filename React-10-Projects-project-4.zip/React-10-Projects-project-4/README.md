
# React 10 PRACTICE PROJECT FOR BEGINNERS
## Project 4 - Foody Zone

![Main Page](https://github.com/anshuopinion/React-10-Projects/assets/50476777/713b76c2-1f25-4081-85d9-e90851c49e61)


Project that we are going to build in this complete practice course

- Project 1 - BRAND LANDING PAGE
- Project 2 - CONTACT US PAGE
- Project 3 - DICE GAME
- Project 4 - FOODY ZONE 
- Project 5 - COMMING SOON
- Project 6 - COMMING SOON
- Project 7 - COMMING SOON
- Project 8 - COMMING SOON
- Project 9 - COMMING SOON
- Project 10 - COMMING SOON

Figma Design URL - https://www.figma.com/file/rephrU2FVgN8MFz6XhnP51/Learn-React-with-10-Projects?type=design&node-id=343-53&t=6WELmKB9oX66NYBS-0

Visit Website For More Details - https://dosomecoding.com


